class Follow<ActiveRecord::Base

end
